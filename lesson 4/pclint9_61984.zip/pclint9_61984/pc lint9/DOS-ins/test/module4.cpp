
#include "test.h"

int main()
    {
    NamedArray na;
    }

