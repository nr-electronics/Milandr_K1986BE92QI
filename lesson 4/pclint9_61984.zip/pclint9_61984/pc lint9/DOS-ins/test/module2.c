
int alpha(unsigned long l)
    {
    return (unsigned) l >> 16;
    }

