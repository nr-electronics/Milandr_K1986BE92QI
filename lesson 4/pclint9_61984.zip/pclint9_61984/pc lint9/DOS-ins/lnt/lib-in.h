
//  lib-in.h
typedef void * selector;
