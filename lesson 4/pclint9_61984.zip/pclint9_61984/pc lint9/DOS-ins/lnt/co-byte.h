
#define sharp_portr( x ) unsigned x;
#define sharp_portrw( x ) unsigned x;
#define sharp_portw( x ) unsigned x;
